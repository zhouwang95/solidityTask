MemeToken 操作指南
1. 环境准备
1.1 开发环境
    使用 Remix IDE（https://remix.ethereum.org/）
    需要 Metamask 钱包插件
1.2 依赖安装
    OpenZeppelin 合约库：npm install @openzeppelin/contracts

2. 合约部署
2.1 编译合约
    在 Remix 中创建新文件MemeToken.sol
    复制上述合约代码到文件中
    选择 Solidity 编译器版本 0.8.17
    点击 "Compile MemeToken.sol"
2.2 部署合约
    在 Remix 的 "Deploy & Run Transactions" 面板中
    环境选择 "Injected Web3"（连接 Metamask）
    选择部署账户（确保有足够 ETH 支付 gas）
    在合约下拉菜单中选择 "MemeToken"
    输入构造函数参数：
    代币名称（如 "MyMemeToken"）
    代币符号（如 "MMT"）
    总供应量（如 1000000000，会自动乘以 10^18）
    点击 "Deploy"，确认 Metamask 中的交易

3. 初始设置
3.1 初始化流动性池
    在已部署的合约中找到initializeLiquidityPool函数
    输入 Uniswap V2 Router 地址：
    以太坊主网：0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D
    测试网（如 Goerli）：根据测试网 Uniswap 部署地址填写
    点击 "transact"，确认交易
    3.2 添加初始流动性
    调用approve函数，批准合约使用你的代币（数量设为你要添加的流动性数量）
    调用addLiquidity函数：
    输入要添加的代币数量（tokenAmount）
    在 "Value" 字段输入要添加的 ETH 数量
    点击 "transact"，确认交易
    3.3 配置税收和交易限制（可选）
    更新税率：调用updateTaxes函数设置新的买入、卖出和转账税率
    更新税收分配：调用updateTaxDistribution设置税收分配比例
    更新交易限制：调用updateTransactionLimits设置单笔最大交易和每日最大交易次数
    设置特殊地址：调用setExcludedFromLimits添加不受交易限制的地址

4. 代币交易
4.1 普通转账
    调用transfer函数：
    输入接收地址（recipient）
    输入转账数量（amount）
    点击 "transact"，确认交易
    注意：转账将自动扣除相应税费
4.2 在 Uniswap 交易
    前往 Uniswap 网站（https://app.uniswap.org/）
    连接你的钱包
    点击 "Select a token"，输入你的代币合约地址
    选择交易方向（买入或卖出）
    输入交易数量，点击 "Swap" 并确认交易

5. 流动性管理
5.1 添加流动性
    确保已批准合约使用你的代币
    调用addLiquidity函数：
    输入要添加的代币数量
    输入对应的 ETH 数量（在 Value 字段）
    确认交易
    交易完成后，你将收到 LP 代币，代表你在流动性池中的份额
5.2 移除流动性
    前往 Uniswap 网站
    进入 "Pool" 页面，点击 "Your liquidity"
    找到你添加的流动性对，点击 "Remove"
    选择要移除的比例
    点击 "Approve" 和 "Remove"，确认交易
    
6. 常见问题解决
6.1 交易失败
    检查是否超过交易限制（单笔最大数量或每日次数）
    检查钱包余额是否充足（包括支付 gas 的 ETH）
    检查是否已批准足够的代币额度
6.2 税收计算问题
    买入、卖出和普通转账的税率可能不同
    税收会自动分配到指定钱包，无需额外操作
6.3 流动性池问题
    确保已正确初始化流动性池
    添加流动性时需要同时提供代币和 ETH
    移除流动性将同时返还两种资产
7. 安全注意事项
    不要向未经验证的合约地址转账
    大额操作前先进行小额测试
    定期检查税收流向和流动性池状态
    谨慎设置不受限制的地址，避免安全风险